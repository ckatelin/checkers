#include <project.h>

mt_test_is_something(isalnum);
