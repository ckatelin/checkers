#include <stdio.h>

int main(int ac, char **av)
{
	printf("hello world\n");
	(void)ac;
	(void)av;
	return (0);
}
