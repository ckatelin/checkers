#include <libft.h>
char	*ft_strrev(char *str)
{
	return (str);
}
