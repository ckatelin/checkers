#include <libft.h>
char	*ft_strupcase(char *str)
{
	return (str);
}
