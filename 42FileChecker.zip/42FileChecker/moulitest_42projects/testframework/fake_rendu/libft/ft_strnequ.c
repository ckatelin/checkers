#include <libft.h>
int		ft_strnequ(char const *s1, char const *s2, size_t n)
{
	(void)s1;
	(void)s2;
	(void)n;
	return (1);
}
