#include <libft.h>
char	*ft_strrchr(const char *s, int c)
{
	(void)c;
	return ((char *)s);
}
