#include <libft.h>
char	*ft_strstr(const char *s1, const char *s2)
{
	(void)s2;
	return ((char *)s1);
}
