#include <libft.h>
char	*ft_strdup(const char *s1)
{
return ((char *)s1);
}
